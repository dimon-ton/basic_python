from mynameiskat.dimon import Dimon

