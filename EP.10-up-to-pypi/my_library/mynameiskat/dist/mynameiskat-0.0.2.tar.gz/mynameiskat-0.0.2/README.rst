แพ็คเก็จนี้เป็นแพ็คเก็จไพธอนที่แสดงข้อมูลเกี่ยวกับ Dimon-ton
============================================================

PyPi: https://pypi.org/project/mynameisdimon/

สวัสดีจ้าาาา นี่คือแพ็คเก็จที่แสดงข้อมูลเกี่ยวกับ Dimon-ton
ท่านสามารถที่จะดูลิงค์เฟสบุค ลิงค์ยูทูป ลิงค์เพจได้ แสดงภาพศิลปะ ASCII

วิธีติดตั้ง
~~~~~~~~~~~

เปิด CMD / Terminal

.. code:: python

   pip install mynameisdimon

วิธีใช้งานแพ็คเพจนี้
~~~~~~~~~~~~~~~~~~~~

-  เปิด IDLE ขึ้นมาแล้วพิมพ์…

.. code:: python

   from mynameisdimon import Dimon

   user = Dimon() #ประกาศชื่อคลาส
   user.show_name() #โชว์ชื่อ
   user.show_youtube() #โชว์ลิงค์ยูทูป
   user.show_page() #โชว์เพจ
   user.about() #โชว์เกียวกับฉัน
   user.show_art() #โชว์ศิลปะ

พัฒนาโดย: ลุงวิศวกร สอนคำนวณ FB: https://www.facebook.com/UncleEngineer

YouTube: https://www.youtube.com/UncleEngineer
