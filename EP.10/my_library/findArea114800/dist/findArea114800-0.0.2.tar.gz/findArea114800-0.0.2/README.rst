คลาสหาพื้นที่ทางเรขาคณิต
========================

แพ็คเก็จนี้คือแพ็คเก็จที่ใช้หาพื้นที่ทางเรขาคณิต

วิธีติดตั้ง
~~~~~~~~~~~

เปิด CMD / Terminal

.. code:: python

   pip install findArea114800

วิธีใช้งานแพ็คเพจนี้
~~~~~~~~~~~~~~~~~~~~

-  เปิด IDLE ขึ้นมาแล้วพิมพ์…

.. code:: python

   from findArea114800 import Area

   a = Area()
   a.circle(12)
   a.triangle(45,98)
   a.square(154)
   a.rectangle(154,567)

พัฒนาโดย: Dimon-ton
